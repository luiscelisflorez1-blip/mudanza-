
import React, { useState, useEffect, useRef } from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Toaster } from '@/components/ui/toaster';
import { useToast } from '@/components/ui/use-toast';
import Header from '@/components/Header';
import MenuSection from '@/components/MenuSection';
import OrderSection from '@/components/OrderSection';
import DrinksSection from '@/components/DrinksSection';
import OtherProductsSection from '@/components/OtherProductsSection';
import FastFoodSection from '@/components/FastFoodSection';

const PIZZA_FLAVORS_KEY = 'pizzaFlavors';

const baseFlavors = [
  {
    id: 2,
    name: 'Pepperoni',
    description: 'pepperoni, finas hierbas y queso',
    price: 10000,
    image: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?w=400&h=300&fit=crop'
  },
  {
    id: 4,
    name: 'Carnes',
    description: 'salami, pollo, cabanio y queso',
    price: 9000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/f5be4baaadf2940f57c3493f9c4a252c.jpg'
  },
  {
    id: 6,
    name: 'Hawaiana',
    description: 'salami, piña y queso',
    price: 9000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/d8eb6f8c5f33952e73e75f4a80f342d7.jpg'
  },
  {
    id: 7,
    name: 'Mexicana',
    description: 'pimenton, cebolla, cabano, pollo, carne molida, cabano y queso',
    price: 10000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/13947c28f6a7cd09d513599863f47ec2.jpg'
  },
  {
    id: 8,
    name: 'Americana',
    description: 'salchicha americana, cebolla, papa triturada, piña y queso',
    price: 10000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/a6a76f6bba9bbf1040f92e1f4a2cb8c2.jpg'
  },
  {
    id: 10,
    name: 'Solo Pollo',
    description: 'pollo y queso',
    price: 12000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/ff559829aed682626b7276ad575b5526.jpg'
  },
  {
    id: 11,
    name: 'Criolla',
    description: 'maduro, maiz, carne desmechada, salami, cabano y queso',
    price: 10000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/0b3e24ed8ee3cfde231f47082932a38a.jpg'
  },
  {
    id: 12,
    name: 'Veleña',
    description: 'bocadillo y queso',
    price: 10000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/b94e426fc72ba0cb9ed302d5ee712d95.jpg'
  },
  {
    id: 13,
    name: 'Pizza de jamon y queso',
    description: 'jamon y queso',
    price: 12000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/d0450c1c3a61b5d96405dcec0469aa1c.jpg'
  },
  {
    id: 14,
    name: 'Pizza Vegetariana',
    description: 'champiñón, cebolla, pimento, maiz y queso',
    price: 10000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/4da3cd4b31d8fabb774ae30083088518.jpg'
  },
  {
    id: 15,
    name: 'Champiñón',
    description: 'champiñón, pollo y queso',
    price: 9000,
    image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/4da3cd4b31d8fabb774ae30083088518.jpg'
  }
];

const drinksData = [
    {
        id: 101,
        name: 'Bebidas Personales',
        description: 'Refrescantes bebidas individuales.',
        price: 4000,
        image: 'https://images.unsplash.com/photo-1551024709-8f23befc6f81?w=400&h=300&fit=crop'
    },
    {
        id: 102,
        name: 'Bebidas Litro y Medio',
        description: 'Para compartir en familia.',
        price: 8000,
        image: 'https://images.unsplash.com/photo-1527960471264-932f39eb5846?w=400&h=300&fit=crop'
    }
];

const otherProductsData = [
    {
        id: 201,
        name: 'Morrongo (Medio)',
        description: 'Deliciosa picada para compartir.',
        price: 35000,
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/3fef792d0bed7a863f2cad1ee1af82a6.jpg'
    },
    {
        id: 202,
        name: 'Morrongo (Completo)',
        description: 'La picada completa para toda la familia.',
        price: 65000,
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/3fef792d0bed7a863f2cad1ee1af82a6.jpg'
    }
];

const fastFoodGroupData = [
    {
        id: 300,
        name: 'Hamburguesa Sencilla',
        description: 'carne, jamon, queso, cebolla y tomate',
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/63f468d798065b842c0894a273970701.jpg',
        variants: [
            { id: 301, name: 'Con papas', price: 25000 },
            { id: 302, name: 'Sin papas', price: 20000 },
        ]
    },
    {
        id: 310,
        name: 'Hamburguesa de Pechuga',
        description: 'filete de pechuga, jamon, queso, cebolla y tomate',
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/e9a00bdfeba8b843bd0742b10701f48e.jpg',
        variants: [
            { id: 303, name: 'Con papas', price: 30000 },
            { id: 304, name: 'Sin papas', price: 25000 },
        ]
    },
    {
        id: 320,
        name: 'Hamburguesa Mixta',
        description: 'carne, pollo desmechado, jamon, tomate, queso, cebolla',
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/e9a00bdfeba8b843bd0742b10701f48e.jpg',
        variants: [
            { id: 305, name: 'Con papas', price: 30000 },
            { id: 306, name: 'Sin papas', price: 25000 },
        ]
    },
    {
        id: 330,
        name: 'Hamburguesa Doble Carne',
        description: 'doble carne, jamon, doble queso, tomate y cebolla',
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/e9a00bdfeba8b843bd0742b10701f48e.jpg',
        variants: [
            { id: 307, name: 'Con papas', price: 32000 },
            { id: 308, name: 'Sin papas', price: 27000 },
        ]
    },
    {
        id: 340,
        name: 'Hamburguesa Especial',
        description: 'carne, pollo desmechado, tocineta, doble queso, huevo, cebolla y tomate',
        image: 'https://horizons-cdn.hostinger.com/c3a947c9-89ec-44f2-aee8-ddad15aac58b/e9a00bdfeba8b843bd0742b10701f48e.jpg',
        variants: [
            { id: 309, name: 'Con papas', price: 35000 },
            { id: 311, name: 'Sin papas', price: 30000 },
        ]
    }
];

const allFastFoodItems = fastFoodGroupData.flatMap(group => 
    group.variants.map(variant => ({
        id: variant.id,
        name: `${group.name} (${variant.name})`,
        description: group.description,
        price: variant.price,
        image: group.image
    }))
);

const initialOrderFormState = {
  name: 'CLIENTE',
  phone: '0000000000',
  address: '',
  tableNumber: '',
  paymentMethod: 'efectivo',
  recommendations: '',
};

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { toast } = useToast();
  const [pizzaFlavors, setPizzaFlavors] = useState(() => {
    try {
      const storedFlavorsJSON = localStorage.getItem(PIZZA_FLAVORS_KEY);
      let currentFlavors = [];

      if (storedFlavorsJSON) {
        currentFlavors = JSON.parse(storedFlavorsJSON);
      } else {
        currentFlavors = [];
      }
      
      const combinedFlavors = [...baseFlavors];
      const seenIds = new Set();
      const uniqueFlavors = [];

      // Filter out specific legacy flavors
      const filteredCurrentFlavors = currentFlavors.filter(flavor => 
        flavor.id !== 1 && 
        flavor.id !== 3 &&
        flavor.id !== 9 &&
        flavor.name.toLowerCase() !== 'vegetariana'
      );

      // Add filtered stored flavors, prioritizing them if they exist but ensuring uniqueness
      filteredCurrentFlavors.forEach(flavor => {
        if (!seenIds.has(flavor.id)) {
          uniqueFlavors.push(flavor);
          seenIds.add(flavor.id);
        }
      });

      // Add base flavors, ensuring they are either new or update existing ones
      combinedFlavors.forEach(baseFlavor => {
        const existingIndex = uniqueFlavors.findIndex(f => f.id === baseFlavor.id);
        if (existingIndex !== -1) {
          uniqueFlavors[existingIndex] = { ...uniqueFlavors[existingIndex], ...baseFlavor };
        } else {
          uniqueFlavors.push(baseFlavor);
        }
        seenIds.add(baseFlavor.id); // Ensure ID is marked as seen
      });
      
      return uniqueFlavors;
    } catch (error) {
      console.error("Error reading from localStorage", error);
      return baseFlavors;
    }
  });

  const [cart, setCart] = useState({});
  const [orderForm, setOrderForm] = useState(initialOrderFormState);
  const [deliveryCost, setDeliveryCost] = useState(0);
  const printFrameRef = useRef(null);

  useEffect(() => {
    try {
      localStorage.setItem(PIZZA_FLAVORS_KEY, JSON.stringify(pizzaFlavors));
    } catch (error) {
      console.error("Error writing to localStorage", error);
    }
  }, [pizzaFlavors]);

  const updateCart = (itemId, quantity) => {
    setCart(prev => {
      const newCart = { ...prev };
      if (quantity > 0) {
        newCart[itemId] = quantity;
      } else {
        delete newCart[itemId];
      }
      return newCart;
    });
  };

  const addToCart = (itemId) => {
    const currentQuantity = cart[itemId] || 0;
    updateCart(itemId, currentQuantity + 1);
    
    const allProducts = [...pizzaFlavors, ...drinksData, ...otherProductsData, ...allFastFoodItems];
    const product = allProducts.find(p => p.id === itemId);
    
    if (product) {
        toast({
            title: `¡Producto añadido!`,
            description: `Se ha añadido ${product.name} al carrito.`,
        });
    }
  };

  const getTotalPrice = () => {
    const allProducts = [...pizzaFlavors, ...drinksData, ...otherProductsData, ...allFastFoodItems];
    const subtotal = Object.entries(cart).reduce((total, [itemId, quantity]) => {
      const product = allProducts.find(p => p.id === parseInt(itemId));
      return total + (product ? product.price * quantity : 0);
    }, 0);
    const total = subtotal + (Number(deliveryCost) || 0);
    return total;
  };

  const validateOrder = () => {
    const isDelivery = !!orderForm.address;
    const isLocal = !!orderForm.tableNumber;
  
    if (!orderForm.name || !orderForm.phone) {
      toast({
        title: "Campos requeridos",
        description: "Por favor completa tu nombre y celular.",
        variant: "destructive"
      });
      return false;
    }
  
    if (isDelivery && !orderForm.address) {
      toast({
        title: "Dirección requerida",
        description: "Por favor ingresa tu dirección para el domicilio.",
        variant: "destructive"
      });
      return false;
    }

    if (!isDelivery && !isLocal) {
        toast({
          title: "Define tu pedido",
          description: "Por favor, ingresa una dirección o selecciona una mesa.",
          variant: "destructive"
        });
        return false;
    }

    if (Object.keys(cart).length === 0) {
      toast({
        title: "Carrito vacío",
        description: "Agrega al menos un producto a tu pedido desde el menú.",
        variant: "destructive"
      });
      return false;
    }
    return true;
  };

  const generateOrderMessage = () => {
    let message = `🍕 *NUEVO PEDIDO - PIZZERÍA RINCÓN DE LAS CIGARRAS*\n\n`;
    message += `👤 *Cliente:* ${orderForm.name}\n`;
    message += `📱 *Celular:* ${orderForm.phone}\n`;
    
    if (orderForm.tableNumber) {
        message += `🍽️ *Mesa:* ${orderForm.tableNumber}\n\n`;
    } else {
        message += `📍 *Dirección:* ${orderForm.address}\n\n`;
    }

    if (orderForm.recommendations) {
      message += `📝 *Recomendaciones:* ${orderForm.recommendations}\n\n`;
    }
    message += `📋 *PEDIDO:*\n`;

    const allProducts = [...pizzaFlavors, ...drinksData, ...otherProductsData, ...allFastFoodItems];
    let subtotal = 0;
    Object.entries(cart).forEach(([itemId, quantity]) => {
      const product = allProducts.find(p => p.id === parseInt(itemId));
      if (product) {
        const itemTotal = product.price * quantity;
        subtotal += itemTotal;
        message += `• ${product.name} x${quantity} - ${itemTotal.toLocaleString()}\n`;
      }
    });

    message += `\n*Subtotal:* ${subtotal.toLocaleString()}\n`;
    const numericDeliveryCost = Number(deliveryCost) || 0;
    if (numericDeliveryCost > 0) {
        message += `*Domicilio:* ${numericDeliveryCost.toLocaleString()}\n`;
    }
    message += `\n💰 *GRAN TOTAL: ${getTotalPrice().toLocaleString()}*\n`;
    message += `💳 *Forma de pago:* ${orderForm.paymentMethod}\n`;

    if (orderForm.paymentMethod === 'transferencia') {
      message += `\n\n*IMPORTANTE:* El pedido se procesará una vez se confirme la transferencia. Por favor, envía el comprobante.`;
    }

    return message;
  };
  
  const generatePrintableHTML = () => {
    let subtotal = 0;
    let html = `
      <div style="font-family: monospace; color: black; width: 70mm; padding: 5px; font-size: 14px;">
        <div style="text-align: center; margin-bottom: 10px;">
          <h1 style="font-weight: bold; font-size: 18px; margin: 0; color: black;">Pizzería Rincón de las Cigarras</h1>
          <p style="font-size: 14px; margin: 3px 0; color: black;">Tel: 3173785955</p>
          <p style="font-size: 14px; margin: 0; color: black;">Calle 61 #8-77</p>
        </div>

        <div style="border-top: 1px dashed black; padding-top: 10px; margin-top: 10px; font-size: 14px; color: black;">
          <p style="margin: 3px 0; color: black;"><strong>Cliente:</strong> ${orderForm.name}</p>
          <p style="margin: 3px 0; color: black;"><strong>Teléfono:</strong> ${orderForm.phone}</p>
          ${orderForm.tableNumber 
            ? `<p style="margin: 3px 0; color: black;"><strong>Mesa:</strong> ${orderForm.tableNumber}</p>`
            : `<p style="margin: 3px 0; color: black;"><strong>Dirección:</strong> ${orderForm.address}</p>`
          }
          ${orderForm.recommendations ? `<p style="margin: 3px 0; color: black;"><strong>Recomendaciones:</strong> ${orderForm.recommendations}</p>` : ''}
        </div>

        <div style="border-top: 1px dashed black; padding-top: 10px; margin-top: 10px;">
          <table style="width: 100%; font-size: 14px; border-collapse: collapse; color: black;">
            <thead>
              <tr style="border-bottom: 1px solid black;">
                <th style="text-align: left; padding-bottom: 5px; color: black;">Cant.</th>
                <th style="text-align: left; padding-bottom: 5px; color: black;">Producto</th>
                <th style="text-align: right; padding-bottom: 5px; color: black;">Subtotal</th>
              </tr>
            </thead>
            <tbody>
    `;
    const allProducts = [...pizzaFlavors, ...drinksData, ...otherProductsData, ...allFastFoodItems];
    Object.entries(cart).forEach(([itemId, quantity]) => {
      const product = allProducts.find(p => p.id === parseInt(itemId));
      if (product) {
        const itemTotal = product.price * quantity;
        subtotal += itemTotal;
        html += `
          <tr>
            <td style="padding: 4px 0; color: black;">${quantity}x</td>
            <td style="padding: 4px 0; color: black;">${product.name}</td>
            <td style="text-align: right; padding: 4px 0; color: black;">${itemTotal.toLocaleString()}</td>
          </tr>
        `;
      }
    });

    const numericDeliveryCost = Number(deliveryCost) || 0;
    html += `
            </tbody>
          </table>
        </div>
        <div style="margin-top: 10px; text-align: right; border-top: 1px dashed black; padding-top: 10px; color: black;">
          <p style="font-size: 14px; margin:0; color: black;">Subtotal: ${subtotal.toLocaleString()}</p>
          ${numericDeliveryCost > 0 ? `<p style="font-size: 14px; margin:0; color: black;">Domicilio: ${numericDeliveryCost.toLocaleString()}</p>` : ''}
          <p style="font-size: 17px; font-weight: bold; margin:5px 0 0 0; color: black;">GRAN TOTAL: ${getTotalPrice().toLocaleString()}</p>
        </div>
    `;
    if (orderForm.paymentMethod === 'transferencia') {
      html += `
        <div style="text-align: center; margin-top: 15px; font-size: 14px; font-weight: bold; border-top: 1px dashed black; padding-top: 10px; color: black;">
          <p style="margin:0; color: black;">YA SE PAGÓ POR TRANSFERENCIA</p>
          <p style="margin:0; color: black;">POR FAVOR VERIFICAR</p>
        </div>
      `;
    }
    html += `</div>`;
    return html;
  };
  
  const triggerPrint = () => {
    const printContent = generatePrintableHTML();
    const frame = printFrameRef.current;
    
    if (!frame.contentWindow) {
        toast({
            title: "Error de Impresión",
            description: "No se pudo acceder al marco de impresión.",
            variant: "destructive",
        });
        return;
    }

    const doc = frame.contentWindow.document;

    doc.open();
    doc.write('<html><head><title>Pedido</title>');
    doc.write('<style>');
    doc.write('@page { size: 70mm auto; margin: 0; }');
    doc.write('@media print { body { -webkit-print-color-adjust: exact; } }');
    doc.write('body { margin: 3mm; background: white; color: black; }');
    doc.write('</style></head><body>');
    doc.write(printContent);
    doc.write('</body></html>');
    doc.close();

    frame.contentWindow.focus();
    frame.contentWindow.print();
  };

  const sendOrderAndPrint = () => {
    if (!validateOrder()) return;

    if (orderForm.paymentMethod === 'transferencia') {
      toast({
        title: "Confirmación de Transferencia",
        description: "Recuerda que debes esperar la confirmación de la transferencia antes de que tu pedido sea procesado. Envía el comprobante por WhatsApp.",
        duration: 8000,
      });
    }

    const message = generateOrderMessage();
    const whatsappUrl = `https://wa.me/573173785955?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
    
    setTimeout(() => {
        triggerPrint();
        setCart({});
        setOrderForm(initialOrderFormState);
        setDeliveryCost(0);
    }, 500);
  };

  const handleFormFieldChange = (field, value) => {
    setOrderForm(prev => {
      const newState = {...prev, [field]: value };
      if (field === 'address' && value !== '') {
        newState.tableNumber = '';
      }
      if (field === 'tableNumber' && value !== '') {
        newState.address = '';
        setDeliveryCost(0);
      }
      return newState;
    });
  };

  return (
    <div className="min-h-screen">
      <div className="fixed inset-0 bg-gradient-to-br from-red-800 via-red-900 to-black -z-10" />
      <Helmet>
        <title>Pizzería Rincón de las Cigarras - Haz tu Pedido</title>
        <meta name="description" content="Selecciona tus pizzas favoritas, completa tus datos y envía tu pedido directamente. ¡Fácil y rápido!" />
      </Helmet>

      <Header isMenuOpen={isMenuOpen} setIsMenuOpen={setIsMenuOpen} />

      <main className="container mx-auto px-4 py-8">
        <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
            className="grid lg:grid-cols-12 gap-8 items-start"
        >
            <div className="lg:col-span-7 space-y-12">
                <MenuSection
                    pizzaFlavors={pizzaFlavors}
                    addToCart={addToCart}
                />
                 <FastFoodSection
                    products={fastFoodGroupData}
                    addToCart={addToCart}
                />
                <DrinksSection
                    drinks={drinksData}
                    addToCart={addToCart}
                />
                <OtherProductsSection
                    products={otherProductsData}
                    addToCart={addToCart}
                />
            </div>
            <div className="lg:col-span-5 lg:sticky lg:top-24">
                <OrderSection
                    orderForm={orderForm}
                    setOrderForm={handleFormFieldChange}
                    products={[...pizzaFlavors, ...drinksData, ...otherProductsData, ...allFastFoodItems]}
                    cart={cart}
                    updateCart={updateCart}
                    getTotalPrice={getTotalPrice}
                    sendOrderAndPrint={sendOrderAndPrint}
                    deliveryCost={deliveryCost}
                    setDeliveryCost={setDeliveryCost}
                />
            </div>
        </motion.div>
      </main>
      
      <iframe ref={printFrameRef} style={{ height: '0', width: '0', position: 'absolute', border: 'none' }} title="Contenido para Impresión"></iframe>
      <Toaster />
    </div>
  );
}

export default App;
