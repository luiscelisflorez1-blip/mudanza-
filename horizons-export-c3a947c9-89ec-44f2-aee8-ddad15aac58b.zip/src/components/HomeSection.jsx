
import React from 'react';

const HomeSection = () => {
  return null;
};

export default HomeSection;
