
import React from 'react';

const Navigation = ({ activeSection, setActiveSection }) => {
  return null;
};

export default Navigation;
